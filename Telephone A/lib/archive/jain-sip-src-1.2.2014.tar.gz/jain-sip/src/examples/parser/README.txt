This example shows  you how to use the factory API to parse sip messages (requests and responses). JSIP can thus be used
for parsing SIP Messsages that have been captured through other means (i.e. a sniffer or tunneled via HTTP ).

