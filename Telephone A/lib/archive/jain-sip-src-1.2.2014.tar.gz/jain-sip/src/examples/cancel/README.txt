
Illustrates how to cancel an INVITE. 


Shootist.java and Shootme.java are the UAC and UAS respectively. 
Focus your attention on these two files to understand the cancel 
processing pattern for JainSip.

To run the example, 

Run ant shootme and ant shootist in two command prompts.

You can examine the generated signaling trace using the traces viewer.


-------------------------------------------------------------------

AbstractCancelTest.java, TestCancel.java and TestDelayedCancel.java
are Junit test wrappers for automated testing. You dont need 
to look at these to understand how the example works.

